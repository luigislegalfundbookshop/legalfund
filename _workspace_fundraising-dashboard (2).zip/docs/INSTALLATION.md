# Installation Guide - Fundraising Analytics Dashboard

## 🚀 Quick Start

### Prerequisites
- Python 3.8 or higher
- Modern web browser (Chrome, Firefox, Safari, Edge)
- 2GB+ available disk space

### Option 1: Web Dashboard (Recommended)
1. **Clone the repository**
   ```bash
   git clone https://github.com/your-username/fundraising-dashboard.git
   cd fundraising-dashboard
   ```

2. **Open the dashboard**
   ```bash
   # Open main dashboard in your browser
   open comprehensive_dashboard.html
   
   # Or use Python's built-in server
   python -m http.server 8000
   # Then visit http://localhost:8000
   ```

### Option 2: Full Python Installation
1. **Clone and setup**
   ```bash
   git clone https://github.com/your-username/fundraising-dashboard.git
   cd fundraising-dashboard
   ```

2. **Create virtual environment**
   ```bash
   python -m venv fundraising_env
   source fundraising_env/bin/activate  # On Windows: fundraising_env\Scripts\activate
   ```

3. **Install dependencies**
   ```bash
   pip install -r requirements.txt
   ```

4. **Run analysis script**
   ```bash
   python anomaly_adjusted_analysis.py
   ```

## 📋 Requirements

### Python Dependencies
```txt
pandas>=1.5.0
numpy>=1.21.0
matplotlib>=3.5.0
seaborn>=0.11.0
plotly>=5.0.0
scipy>=1.9.0
scikit-learn>=1.1.0
```

### System Requirements
- **Operating System**: Windows 10+, macOS 10.14+, Ubuntu 18.04+
- **RAM**: 4GB minimum (8GB recommended)
- **Storage**: 2GB free space
- **Browser**: Modern browser with JavaScript enabled

## 🔧 Configuration

### Data Setup
1. **Prepare your data**
   - CSV format with columns: Date, Donations_USD, Donors
   - Date format: YYYY-MM-DD or MM/DD/YYYY
   - Remove sensitive information before analysis

2. **Update data source**
   ```bash
   # Replace with your data file
   cp your_fundraising_data.csv complete_fundraising_data.csv
   ```

### Customization Options
1. **Anomaly Threshold Adjustment**
   ```python
   # In anomaly_adjusted_analysis.py, line 15
   anomaly_threshold = 30000  # Adjust based on your data
   ```

2. **Donor Segmentation Parameters**
   ```python
   # Modify segmentation criteria in the analysis script
   # Adjust gift amounts, donor counts, and behavior patterns
   ```

## 🌐 Deployment Options

### GitHub Pages (Free)
1. **Push to GitHub**
   ```bash
   git add .
   git commit -m "Deploy fundraising dashboard"
   git push origin main
   ```

2. **Enable GitHub Pages**
   - Go to repository settings
   - Scroll to "GitHub Pages"
   - Select source: "Deploy from a branch"
   - Choose main branch and / (root)
   - Save and visit your site

### Netlify (Recommended)
1. **Connect repository**
   - Sign up for Netlify
   - Connect your GitHub repository
   - Build settings: No build command needed
   - Publish directory: . (root)

2. **Custom domain**
   - Available for free with Netlify
   - Automatic HTTPS certificate

### Vercel
1. **Import project**
   - Go to Vercel dashboard
   - Import GitHub repository
   - Framework preset: Other
   - Build settings: No build needed

## 🚨 Troubleshooting

### Common Issues

**Dashboard not loading**
- Check browser JavaScript is enabled
- Try different browser
- Clear browser cache and cookies

**Analysis script errors**
```bash
# Check Python version
python --version  # Should be 3.8+

# Update packages
pip install --upgrade pandas numpy

# Check data format
head complete_fundraising_data.csv
```

**Mobile display issues**
- Ensure responsive meta tag is present
- Check viewport settings
- Test with Chrome DevTools

### Performance Optimization

**Large datasets**
```python
# For datasets > 100K rows, add this to analysis script
import pandas as pd
pd.set_option('display.max_rows', 1000)
pd.set_option('display.float_format', '{:.2f}'.format)
```

**Memory issues**
```bash
# Increase memory allocation for Python
export PYTHONOPTIMIZE=1
python anomaly_adjusted_analysis.py
```

## 🔒 Security Considerations

### Data Privacy
- Remove donor personal information before uploading
- Use anonymized datasets for public repositories
- Consider encryption for sensitive data

### Web Security
- Dashboard runs client-side (no server data transmission)
- No external API calls for core functionality
- Compatible with corporate security policies

## 📞 Support

### Getting Help
1. **Documentation**: Check this guide and project overview
2. **GitHub Issues**: Report bugs or request features
3. **Community**: Join discussions for tips and tricks
4. **Email**: analytics@example.com for direct support

### Contributing
1. Fork the repository
2. Create feature branch: `git checkout -b feature-name`
3. Commit changes: `git commit -m 'Add feature'`
4. Push to branch: `git push origin feature-name`
5. Open Pull Request

---

*Need additional help? Check our [FAQ](FAQ.md) or contact our support team.*